import { double, float, int, TypeConstructor, uint, valuetype } from './common';
import { BaseMat, C, D, mat, Mat2, Mat3, Mat4, R } from './mat';
import { vec, Vec1, Vec2, Vec3, Vec4, VecSize } from './vec';

export namespace glm {
  export function vec1(...args: number[]): vec<float, 1> {
    return new Vec1(Float32Array, args)
  }

  export function vec2(...args: number[]): vec<float, 2> {
    return new Vec2(Float32Array, args);
  }

  export function vec3(...args: number[]): vec<float, 3> {
    return new Vec3(Float32Array, args);
  }

  export function vec4(...args: number[]): vec<float, 4> {
    return new Vec4(Float32Array, args);
  }

  export function ivec1(...args: number[]): vec<int, 1> {
    return new Vec1(Int32Array, args);
  }

  export function ivec2(...args: number[]): vec<int, 2> {
    return new Vec2(Int32Array, args);
  }

  export function ivec3(...args: number[]): vec<int, 3> {
    return new Vec3(Int32Array, args);
  }

  export function ivec4(...args: number[]): vec<int, 4> {
    return new Vec4(Int32Array, args);
  }

  export function uvec1(...args: number[]): vec<uint, 1> {
    return new Vec1(Uint32Array, args)
  }

  export function uvec2(...args: number[]): vec<uint, 2> {
    return new Vec2(Uint32Array, args);
  }

  export function uvec3(...args: number[]): vec<uint, 3> {
    return new Vec3(Uint32Array, args);
  }

  export function uvec4(...args: number[]): vec<uint, 4> {
    return new Vec4(Uint32Array, args);
  }

  export function dvec1(...args: number[]): vec<double, 1> {
    return new Vec1(Float64Array, args)
  }

  export function dvec2(...args: number[]): vec<double, 2> {
    return new Vec2(Float64Array, args);
  }

  export function dvec3(...args: number[]): vec<double, 3> {
    return new Vec3(Float64Array, args);
  }

  export function dvec4(...args: number[]): vec<double, 4> {
    return new Vec4(Float64Array, args);
  }

  export function mat2(...args: number[]): mat<float, 2, 2> {
    return new Mat2(Float32Array, args);
  }

  export function mat3(...args: number[]): mat<float, 3, 3> {
    return new Mat3(Float32Array, args);
  }

  export function mat4(...args: number[]): mat<float, 4, 4> {
    return new Mat4(Float32Array, args);
  }

  export function dmat2(...args: number[]): mat<double, 2, 2> {
    return new Mat2(Float64Array, args);
  }

  export function dmat3(...args: number[]): mat<double, 3, 3> {
    return new Mat3(Float64Array, args);
  }

  export function dmat4(...args: number[]): mat<double, 4, 4> {
    return new Mat4(Float64Array, args);
  }

  export function Mat<TR extends R, TC extends C, TType extends valuetype>(row: TR, col: TC,
    constructor: TypeConstructor<TType>,
    ...args: number[]): mat<TType, TR, TC> {
    return new BaseMat(row, col, args, constructor);
  }
}


function mul<T extends valuetype, S extends 1 >(v1: vec<T, S> , v2: vec<T, S> ): vec<T,S>
function mul<T extends valuetype, S extends 2 >(v1: vec<T, S> , v2: vec<T, S> ): vec<T,S>
function mul<T extends valuetype, S extends 3 >(v1: vec<T, S> , v2: vec<T, S> ): vec<T,S>
function mul<T extends valuetype, S extends 4 >(v1: vec<T, S> , v2: vec<T, S> ): vec<T,S>

function mul<T extends valuetype, S extends D, R extends D>(v1: vec<T,S>, v2: mat<T, R, S>): mat<T, R, S>
function mul<T extends valuetype, S extends D, C extends D>(v1: mat<T, S, C>, v2: vec<T,S>): mat<T, S, C> 
function mul<T extends valuetype, S extends D, R extends D, C extends D>(v1: mat<T, S, C>, v2: mat<T, R, S>): mat<T, R, C>
function mul<T extends valuetype, S extends VecSize , R extends D, C extends D>(v1: vec<T, S> | mat<T, S, C> , v2: vec<T, S> | mat<T, R,C>): vec<T, S> | mat<T, R, C> {
  throw Error('Not implemented');

}

let t1 = glm.vec2();
let t4 = glm.vec3();
let t2 = glm.Mat<3,2, float>(3,2, Float32Array);
let t3 = glm.Mat<2,4, float>(2,4, Float32Array);

let r1 = mul(t1,t2);
let r2 = mul(t2,t4);
let r = mul(t3, t2);
let r3 = mul(t1,t4);