import { glm } from "./glm copy";
import { vec } from "./vec";

export type int = Int32Array;

export type uint = Uint32Array;

export type float = Float32Array;

export type double = Float64Array;

export type VecSize = 1 | 2 | 3 | 4;

export type valuetype = int | uint | float | double;

export type v1 = 1;

export type v2 = 2;

export type v3 = 3;

export type v4 = 4;

export interface TypeConstructor<T extends valuetype> {
  readonly prototype: T;

  new(length: number): T;

  new(array: ArrayLike<number> | ArrayBufferLike): T;

  new(buffer: ArrayBufferLike, byteOffset?: number, length?: number): T;

  readonly BYTES_PER_ELEMENT: number;

  of(...items: number[]): T;

  from(arrayLike: ArrayLike<number>): T;

  from<T>(arrayLike: ArrayLike<T>, mapfn: (v: T, k: number) => number, thisArg?: any): T;
}

export type Tuple<T, N extends number, R extends T[] = []> = R['length'] extends N ? R : Tuple<T, N, [T, ...R]>;

export type IsGreaterOrEqual<A extends number, B extends number> =
  A extends B ? true :
    B extends 1 ? true :
      B extends 2 ? A extends 3 | 4 ? true : false :
        B extends 3 ? A extends 4 ? true : false :
          false;

export type GE<N1 extends number, N2 extends number> = IsGreaterOrEqual<N1, N2> extends true ? N1 : never;

export type Subtract<A extends number, B
extends number> = Tuple<any, A> extends [...(infer U), ...Tuple<any, B>] ? U['length'] : never;


export type Multiply<A extends number, B extends number> =
  A extends 0 ? 0 :
    B extends 0 ? 0 :
      A extends 1 ? B :
        B extends 1 ? A :
          [...Array<A>, ...Array<B>]['length'];


