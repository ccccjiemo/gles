import { float, TypeConstructor, valuetype } from "./common";

type VecSize = 1 | 2 | 3 | 4;

interface nvec<T extends valuetype, TSize extends VecSize> {
  readonly value: T
  readonly size: TSize

  get length(): number
}


export type vec<TType extends valuetype = float, TSize extends VecSize = 1> = nvec<TType, TSize> &
(TSize extends 1 ? d1 : unknown) &
(TSize extends 2 ? d2 : unknown) &
(TSize extends 3 ? d3 : unknown) &
(TSize extends 4 ? d4 : unknown);


interface d1 {
  get x(): number

  set x(value: number)

  get r(): number

  set r(value: number)

  get s(): number

  set s(value: number)
}

interface d2 extends d1 {
  get y(): number

  set y(value: number)

  get g(): number

  set g(value: number)

  get t(): number

  set t(value: number)

  get xy(): vec<any, 2>

  get rg(): vec<any, 2>

  get st(): vec<any, 2>

}

interface d3 extends d2 {
  get z(): number

  set z(value: number)

  get b(): number

  set b(value: number)

  get p(): number

  set p(value: number)

  get xyz(): vec<any, 3>

  get rgb(): vec<any, 3>

  get stp(): vec<any, 3>
}

interface d4 extends d3 {
  get w(): number

  set w(value: number)

  get a(): number

  set a(value: number)

  get q(): number

  set q(value: number)

}


export class VecBase<T extends valuetype, TSize extends VecSize> implements nvec<T, TSize>, d4 {
  readonly value: T;
  readonly size: TSize;
  private readonly typeConstructor: TypeConstructor<T>

  createNew<T extends valuetype>(data: T) {
    return new VecBase(this.size, this.typeConstructor, data);
  }

  constructor(size: TSize, type: TypeConstructor<T>, ...initialData: any[]) {
    this.size = size;
    this.typeConstructor = type;
    let v0 = initialData[0];

    if (typeof v0 == typeof type) {
      this.value = v0;
      return;
    }

    this.value = new type(size);
    //constructor()
    if (initialData.length == 0) {
      return;
    }


    //vec3(vec1, 1,2)
    if (v0 instanceof VecBase) {
      this.value.set(v0.value);
      for (let i = 0; i < initialData.length - 1; i++) {
        this.value[v0.size + i] = initialData[i+1] as unknown as number;
      }
      return;
    }

    //vec3(1)
    if (typeof v0 == 'number' && initialData.length == 1) {
      this.value.fill(v0);
      return;
    }

    //vec3([1,2,3])
    if (Array.isArray(v0)) {
      this.value.set(v0);
      return;
    }

    //vec3(1,2,3)
    this.value.set(initialData as unknown as number[])
  }


  get length(): number {
    return this.value.length;
  }


  get x(): number {
    return this.value[0];
  }

  set x(value: number) {
    this.value[0] = value;
  }

  get r(): number {
    return this.value[0];
  }

  set r(value: number) {
    this.value[0] = value;
  }

  get s(): number {
    return this.value[0];
  }

  set s(value: number) {
    this.value[0] = value;
  }

  get y(): number {
    return this.value[1];
  }

  set y(value: number) {
    this.value[1] = value;
  }

  get g(): number {
    return this.value[1];
  }

  set g(value: number) {
    this.value[1] = value;
  }

  get t(): number {
    return this.value[1];
  }

  set t(value: number) {
    this.value[1] = value;
  }

  get z(): number {
    return this.value[2];
  }

  set z(value: number) {
    this.value[2] = value;
  }

  get b(): number {
    return this.value[2];
  }

  set b(value: number) {
    this.value[2] = value;
  }

  get p(): number {
    return this.value[2];
  }

  set p(value: number) {
    this.value[2] = value;
  }

  get w(): number {
    return this.value[3];
  }

  set w(value: number) {
    this.value[3] = value;
  }

  get a(): number {
    return this.value[3];
  }

  set a(value: number) {
    this.value[3] = value;
  }

  get q(): number {
    return this.value[3];
  }

  set q(value: number) {
    this.value[3] = value;
  }

  get xyz(): vec<any, 3> {
    return new VecBase(3, this.typeConstructor, this.value.slice(0, 3))
  }

  get rgb(): vec<any, 3> {
    return new VecBase(3, this.typeConstructor, this.value.slice(0, 3))
  }

  get stp(): vec<any, 3> {
    return new VecBase(3, this.typeConstructor, this.value.slice(0, 3))
  }

  get xy(): vec<any, 2> {
    return new VecBase(2, this.typeConstructor, this.value.slice(0, 2))
  }

  get rg(): vec<any, 2> {
    return new VecBase(2, this.typeConstructor, this.value.slice(0, 2))
  }

  get st(): vec<any, 2> {
    return new VecBase(2, this.typeConstructor, this.value.slice(0, 2))
  }
}

//
// export class Vec1<T extends valuetype> extends VecBase<T, 1> implements d1 {
//   constructor(type: TypeConstructor<T>, initialData: number[] | VecBase<T, 1>) {
//     super(1, type, initialData);
//   }
//
//   get x(): number {
//     return this.value[0];
//   }
//
//   set x(value: number) {
//     this.value[0] = value;
//   }
//
//   get r(): number {
//     return this.value[0];
//   }
//
//   set r(value: number) {
//     this.value[0] = value;
//   }
//
//   get s(): number {
//     return this.value[0];
//   }
//
//   set s(value: number) {
//     this.value[0] = value;
//   }
// }
//
// export class Vec2<T extends valuetype> extends VecBase<T, 2> implements d2 {
//   constructor(type: TypeConstructor<T>, initialData: number[] | VecBase<T, 2>) {
//     super(2, type, initialData);
//   }
//
//   get x(): number {
//     return this.value[0];
//   }
//
//   set x(value: number) {
//     this.value[0] = value;
//   }
//
//   get r(): number {
//     return this.value[0];
//   }
//
//   set r(value: number) {
//     this.value[0] = value;
//   }
//
//   get s(): number {
//     return this.value[0];
//   }
//
//   set s(value: number) {
//     this.value[0] = value;
//   }
//
//   get y(): number {
//     return this.value[1];
//   }
//
//   set y(value: number) {
//     this.value[1] = value;
//   }
//
//   get g(): number {
//     return this.value[1];
//   }
//
//   set g(value: number) {
//     this.value[1] = value;
//   }
//
//   get t(): number {
//     return this.value[1];
//   }
//
//   set t(value: number) {
//     this.value[1] = value;
//   }
// }
//
// export class Vec3<T extends valuetype> extends VecBase<T, 3> implements d3 {
//   constructor(type: TypeConstructor<T>, initialData: number[] = []) {
//     super(3, type, initialData);
//   }
//
//   get x(): number {
//     return this.value[0];
//   }
//
//   set x(value: number) {
//     this.value[0] = value;
//   }
//
//   get r(): number {
//     return this.value[0];
//   }
//
//   set r(value: number) {
//     this.value[0] = value;
//   }
//
//   get s(): number {
//     return this.value[0];
//   }
//
//   set s(value: number) {
//     this.value[0] = value;
//   }
//
//   get y(): number {
//     return this.value[1];
//   }
//
//   set y(value: number) {
//     this.value[1] = value;
//   }
//
//   get g(): number {
//     return this.value[1];
//   }
//
//   set g(value: number) {
//     this.value[1] = value;
//   }
//
//   get t(): number {
//     return this.value[1];
//   }
//
//   set t(value: number) {
//     this.value[1] = value;
//   }
//
//   get z(): number {
//     return this.value[2];
//   }
//
//   set z(value: number) {
//     this.value[2] = value;
//   }
//
//   get b(): number {
//     return this.value[2];
//   }
//
//   set b(value: number) {
//     this.value[2] = value;
//   }
//
//   get p(): number {
//     return this.value[2];
//   }
//
//   set p(value: number) {
//     this.value[2] = value;
//   }
// }
//
// export class Vec4<T extends valuetype> extends VecBase<T, 4> implements d4 {
//   constructor(type: TypeConstructor<T>, initialData: number[] = []) {
//     super(4, type, initialData);
//   }
//
//   get x(): number {
//     return this.value[0];
//   }
//
//   set x(value: number) {
//     this.value[0] = value;
//   }
//
//   get r(): number {
//     return this.value[0];
//   }
//
//   set r(value: number) {
//     this.value[0] = value;
//   }
//
//   get s(): number {
//     return this.value[0];
//   }
//
//   set s(value: number) {
//     this.value[0] = value;
//   }
//
//   get y(): number {
//     return this.value[1];
//   }
//
//   set y(value: number) {
//     this.value[1] = value;
//   }
//
//   get g(): number {
//     return this.value[1];
//   }
//
//   set g(value: number) {
//     this.value[1] = value;
//   }
//
//   get t(): number {
//     return this.value[1];
//   }
//
//   set t(value: number) {
//     this.value[1] = value;
//   }
//
//   get z(): number {
//     return this.value[2];
//   }
//
//   set z(value: number) {
//     this.value[2] = value;
//   }
//
//   get b(): number {
//     return this.value[2];
//   }
//
//   set b(value: number) {
//     this.value[2] = value;
//   }
//
//   get p(): number {
//     return this.value[2];
//   }
//
//   set p(value: number) {
//     this.value[2] = value;
//   }
//
//   get w(): number {
//     return this.value[3];
//   }
//
//   set w(value: number) {
//     this.value[3] = value;
//   }
//
//   get a(): number {
//     return this.value[3];
//   }
//
//   set a(value: number) {
//     this.value[3] = value;
//   }
//
//   get q(): number {
//     return this.value[3];
//   }
//
//   set q(value: number) {
//     this.value[3] = value;
//   }
// }