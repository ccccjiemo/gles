import { TypeConstructor, valuetype } from "./common";
import { VecBase } from "./vec";


export type Rows = 2 | 3 | 4;

export type Cols = 2 | 3 | 4;

export interface mat<T extends valuetype, R extends number, C extends number> {
  elements: T;
  rows: R;
  cols: C;


}

export class BaseMat<T extends valuetype, R extends number, C extends number> implements mat<T, R, C> {
  elements: T;
  rows: R;
  cols: C;

  constructor(row: R, col: C, type: TypeConstructor<T>, data: any[]) {
    this.rows = row;
    this.cols = col;
    const size = row * col;
    this.elements = new type(size);

    //mat2()
    if (data.length == 0) {
      return;
    }

    let v0 = data[0];
    //mat2(1)
    // if (data.length == 1) {
    //   //mat3(mat2|mat3)
    //   if (v0 instanceof BaseMat) {
    //     for (let i = 0; i < v0.rows; i++) {
    //       for (let j = 0; j < v0.cols; i++) {
    //         this.elements[this.cols * i + j] = v0.elements[v0.cols * i + j];
    //       }
    //     }
    //   } else if (typeof v0 == 'number') { //mat2(1)
    //     let t = Math.min(row, col);
    //     for (let i = 0; i < t; i++) {
    //       this.elements[col * i + i] = v0;
    //     }
    //   } else { //mat2([1,2,3,4])
    //     this.elements.set(v0 as unknown as number[])
    //   }
    //   return;
    // }
    //
    // for (let i = 0; i < this.rows; i++) {
    //   for(let j = 0; j < this.cols;i++){
    //
    //   }
    // }
    //
    // this.elements.set(data as unknown as number[])

    if (typeof v0 === 'number') {
      //标准矩阵mat(1)
      if (data.length == 1) {
        let t = Math.min(row, col);
        for (let i = 0; i < t; i++) {
          this.elements[col * i + i] = v0;
        }
      } else {
        //不定数组mat2(1,2,3,4)
        this.elements.set(data);
      }
    } else if (Array.isArray(v0)) { //mat2([1,2,3,4])
      this.elements.set(v0);
    } else if (v0 instanceof BaseMat) { //mat3(mat2)
      for (let i = 0; i < v0.rows; i++) {
        for (let j = 0; j < v0.cols; i++) {
          this.elements[this.cols * i + j] = v0.elements[v0.cols * i + j];
        }
      }
    } else if (v0 instanceof VecBase) { //mat3(vec3,vec3,vec3)
      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j < this.cols; j++) {
          this.elements[this.cols * i + j] = data[i][j];
        }
      }
    } else {
      throw Error("invalid argument");
    }

  }
}

export class Mat2<T extends valuetype> extends BaseMat<T, 2, 2> {
  constructor(type: TypeConstructor<T>, args: object[]) {
    super(2, 2, type, args);
  }
}

export class Mat3<T extends valuetype> extends BaseMat<T, 3, 3> {
  constructor(type: TypeConstructor<T>, args: object[]) {
    super(3, 3, type, args)
  }
}

export class Mat4<T extends valuetype> extends BaseMat<T, 4, 4> {
  constructor(type: TypeConstructor<T>, args: object[]) {
    super(4, 4, type, args)
  }
}